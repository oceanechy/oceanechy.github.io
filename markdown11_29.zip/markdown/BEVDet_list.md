# BEVDet系列

[BEVDet系列源码解读](https://zhuanlan.zhihu.com/p/557613388)
[BEVDet网络结构](https://blog.csdn.net/guangqianzhang/article/details/129615932)
[BEVDet4D 强大而不失优雅的三维目标检测范式](https://zhuanlan.zhihu.com/p/492106899)
[BEVDet4D讲解](https://zhuanlan.zhihu.com/p/638452999)