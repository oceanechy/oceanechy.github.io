# PON:Predicting Semantic Map Representations from Images using Pyramid Occupancy Networks 

论文链接：[PON-pdf](https://arxiv.org/pdf/2003.13402.pdf)
代码链接：[PON-py](https://github.com/tom-roddick/mono-semantic-maps)

PON:利用金字塔占用网络预测图像的语义地图表示

提出了一个dense transformer（并非self attention的transformer， 只是MLP结构）的网络结构用于将2D图转换成BEV

我们的贡献如下:
 - 提出了一种新的密集变换层，它将基于图像的特征图映射到鸟瞰图空间。
 - 设计了一个深度卷积神经网络架构，其中包括在多个图像尺度上运行的变压器金字塔，以从单眼图像预测准确的鸟瞰图。
 - 我们在两个大规模自动驾驶数据集上评估我们的方法，并表明我们能够显着提高文献中领先作品的性能。
我们还定性地展示了如何使用贝叶斯语义占用网格框架来累积跨多个相机和时间步长的地图预测，以构建完整的场景模型。 该方法足够快，可用于实时应用程序，在单个 GeForce RTX 2080 Ti 显卡上每秒处理 23.2 帧





一些参考链接

[翻译](https://blog.csdn.net/weixin_43889128/article/details/122301675?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522169927967316800213076409%2522%252C%2522scm%2522%253A%252220140713.130102334..%2522%257D&request_id=169927967316800213076409&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~sobaiduend~default-2-122301675-null-null.142^v96^pc_search_result_base3&utm_term=Predicting%20Semantic%20Map%20Representations%20from%20Images%20using%20Pyramid%20Occupancy%20Networks&spm=1018.2226.3001.4187)

[图像到BEV转换](https://blog.csdn.net/Never__Say__No/article/details/120958739?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522169927967316800213076409%2522%252C%2522scm%2522%253A%252220140713.130102334..%2522%257D&request_id=169927967316800213076409&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~sobaiduend~default-4-120958739-null-null.142^v96^pc_search_result_base3&utm_term=Predicting%20Semantic%20Map%20Representations%20from%20Images%20using%20Pyramid%20Occupancy%20Networks&spm=1018.2226.3001.4187)