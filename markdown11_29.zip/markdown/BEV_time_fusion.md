# BEV感知中的时序融合方法（部分待更新）

[参考链接](https://zhuanlan.zhihu.com/p/583682754)

首先展示目前的融合时序的BEV感知算法


 ![BEV感知模型时序融合方法精简汇总](/pic/time2.jpg)

在传统感知算法中,时序融合是提高感知算法准确性和连续性的关键,可以弥补单帧感知的局限性,增加感受野,改善目标检测(Object Detection)帧间跳变和目标遮挡问题,更加准确地判断目标运动速度,同时也对目标预测(Prediction)和跟踪(Tracking)有重要作用.在BEV感知中,时序融合同样可以发挥相应的作用.同时,由于前序帧相关信息可以直接从缓存中读取,并不会带来性能上的大幅下降.下图直观地展示了时序融合的工作原理:

 ![参考BEVFormer论文](/pic/time1.png)


 - 传统的时序融合主要是在后处理中使用RNN或卡尔曼滤波等方式进行融合,这种方式由于要增加额外的开销,影响模型的性能,所以近年来大量采用的是特征级融合.
  - 特征级融合是继前融合,后融合新提出来的方法,不仅可以用在多传感器融合,也可以用在时序融合,具有跨模态,跨时空的特点.
  - 而BEV感知由于自身的特点,存在两个特征域:图像域(自车camera图像坐标系)和BEV域(自车lidar坐标系),这一点可以区别于传统感知算法只有图像域特征,从而BEV感知的时序融合可以在两个特征域任意一个进行,具体融合的方法也有两种:
    - 基于CNN的方式，其中基于CNN的方式又可使用2D卷积和3D卷积
    - 基于Transformer的方式,
    - 基于CNN和Transformer结合的方法.
 - 本文对BEV时序方法的分类主要基于以上几个方面,论文来源基本是2022年的工作.另外由于本文篇幅较长,文末提供精简归纳表格,欢迎阅读下篇获取.

在具体的时序融合方法上,我们主要关注以下几个对融合结果影响较大的方面:
 - 一是如何选择前序帧,这个决定了时序融合的有效范围,
 - 二是如何进行时空对齐(alignment),即将前序帧特征通过ego-motion进行转换,使之与当前帧特征处于同一个坐标系下,这样才可以进行准确的融合,
 - 三是融合的具体方法,
 - 最后是融合的分辨率,是融合效果和性能的折中选择.
 - 数据集方面,以下大部分模型都使用nuscenes数据集,该数据集有1000个场景(scenes),每个scene包括20+精细标注的关键帧(key frame),间隔0.5秒,每两个关键帧之间存在若干无精细标注的非关键帧(sweeps).


## 基于Transformer的BEV特征融合


### BEVFormer

BEVFormer是相对比较早的一个经典BEV感知模型,主体框架是基于transformer生成bev feature,再做基于DETR的目标检测,在之前博客里有详细介绍,主要motion是针对DETR3D的改进,
 - 一是DETR3D只有基于稀疏的object query的decoder, BEVFormer增加了基于稠密的bev query的encoder,可以生成稠密的bev feature,
 - 二是由于有了bev feature,方便进行稠密的任务,如语义分割等,也方便进行时序融合.时序融合在encoder中的Temporal Self-Attention中实现,这个模块本质上就是deformable attention(来自于deformable DETR),只是**query做了前序帧和当前帧的拼接**.

BEVformer在前序帧的选择上,是在**前面4帧中随机选3帧(只包括关键帧)**,所以时序范围为2秒,这3帧不是一次性输入,而是**迭代地进行两两融合**,第一帧由于没有前序帧,只与自己本身融合,也就是每个iteration需要跑**4次前向传播和1次反向传播**.前序bev feature在缓存中直接读取,不会降低推理的效率.

时空对齐方面,由于是**BEV特征域融合**,而两帧的bev特征分别在两帧的自车lidar坐标系下,所以**需要将前序帧的lidar坐标通过ego-motion转换到当前帧的lidar坐标**.这里面又包括两种方式:
 - 变换bev feature和变换reference_points(即密集query对应的坐标值),两种方法需要做的变换略有不同.论文中的做法是旋转feature,平移reference_points,
  - 这里存在一个问题就是论文中旋转feature的方式会产生全0的黑边,不利于后续的融合,而变换reference_points在后续的grid_sample环节会有插值作用,会更加准确.

具体的融合方式上,论文中是在Temporal Self-Attention模块中把时空对齐后的前序bev feature和当前bev feature分别做deformable attention,再在h\*w平面做算术平均进行融合.这里算术平均有点简单粗暴,也可以修改为自适应的融合方式.融合分辨率也就是encoder中query的数量，论文中用的比较大,是200\*200,而decoder的query数量与与之类似的经典bev3D模型DETR3D相同,为900.其中,DETR3D无时序版本,并且只有decoder.

### PolarDETR(华中科大,地平线机器人)

[Polar Parametrization for Vision-based Surround-View 3D Detection](https://arxiv.org/abs/
2206.10965)
[代码链接](https://github.com/hustvl/PolarDETR)

 ![网络框架图](/pic/time3.png)


PolarDETR在整体框架上接近于DETR3D,主要不同点一是bev特征和目标位置的表征和从笛卡尔坐标系转换到了极坐标系,即由半径r,方位角α, 高度z进行表征,二是加入了时序融合.

为什么使用极坐标系的解释,如下图,假设目标At1和At2由于位置和朝向刚好匹配,在两个2D视角内的呈现是完全相同的,bev有效检测范围是d,这时候在笛卡尔坐标系中At1将被过滤掉,而At2会被保留下来,这对于模型训练来讲显然是不利于收敛的,问题就在于笛卡尔坐标系的各个边界点距中心的距离不一致.而如果使用极坐标系,只要两个目标距自车距离相等,就将被同等对待.

 ![](/pic/time4.png)

关于时序融合,本文采用的方式和BEVFormer类似,也是**基于transformer的bev特征融合**,只是这里融合的是
- ==代表目标的object query,而不是代表bev feature的bev query==.
- 时序对齐的方法是在极坐标bev下,把当前帧采样点投影到前序帧获取特征,类似于变换reference_points.
- 融合方法是**所有帧channel维度拼接后做self attention**,区别于BEVFormer的两两迭代融合,但具体用了多少帧由于代码还未公开所以不确定.

 ![性能对比表](/pic/time5.png)


## 基于CNN(2D/3D conv)的BEV特征融合

### BEVDet4D/BEVDepth4D(鉴智机器人)

 ![网络结构图](/pic/time6.png)


BEVDet4D和BEVDepth4D是基于BEVDet和BEVDepth增加时序融合的版本.二者框架非常类似,与BEVFormer属于不同的两种bev表征的方式。BEVDet系列属于基于LSS思想,多视角特征先通过深度估计网络进行像素级的深度估计,再投影到bev空间,通过基于CNN的bev encoder进行编码后连接Centerpoint检测头.BEVDepth4D的主要改进是增加了对深度估计网络的监督,使结果更准确.

具体来说，BEVDet4D的时序融合**发生在投影到bev空间得到bev feature后**,与前序帧先经过时空对齐,在channel维度拼接,再送入bev encoder进行融合.这里的
- 时空对齐是使用grid_sample把前序帧特征warp到当前帧,和直接旋转平移feature或reference_points本质上相同,但博主认为,如果后续还要做deformable self attention进行融合的话,这样处理效率较低,因为还需要再做一次grid_sample来取相应的value,还是直接对reference_points进行变换可以获得较高的效率.不过
- 这里后续是使用CNN进行融合,影响不大.CNN这里用的是2D卷积.因为这种架构需要额外的深度估计网络,所以bev feature分辨率不能太大,文中采用了16倍下采样.
- 在前序帧的选择上,训练阶段是在前3帧或后3帧随机选1帧,推理阶段只在前3帧随机选一帧.训练阶段把后续帧也加进来可以提高鲁棒性.

### BEVerse

[论文链接](https://arxiv.org/abs/2205.09743)
[代码链接](https://github.com/zhangyp15/BEVerse)
[学习文章](https://zhuanlan.zhihu.com/p/518147623)


 ![网络结构图](/pic/time7.png)


BEVerse是一个感知预测一体化模型,
- 主体基于LSS生成bev feature,
- 再经过spatial-temporal bev encoder进行时空编码,-
- 再进行下游的检测分割和预测任务.

由于需要做预测,时序融合成为重要部分,并且需要前序帧和后续帧都要加入训练,选择的帧数相应也会比较多.
- 时序对齐的方法仍然类似于BEVDet4D,只是BEVDet4D只使用1帧前序帧,BEVerse使用的是前2帧+后4帧,每帧都用grid_sample warp到当前帧再进行channel维度的拼接.
- 拼接完成后,模型设计了Temporal3DConvModel进行时序的融合,和上文两个基于CNN融合的模型不同,BEVerse由于使用的帧数比较多,采用3D卷积和3D池化对所有帧进行融合.3D卷积是处理连续帧信息的一个重要方式.分辨率使用的是128*128.



## 基于transformer的图像特征融合

前文所介绍的模型有一个共同点,即都是在bev空间下对bev feature做时序融合.由于每一帧的bev feature只有一个,所以bev空间下的时序融合比较简单直接,可直接通过warp的方式将前序帧与当前帧融合,而且需要的缓存空间也比较小.但这种方法也有不足之处,
- 一是会带来可融合区域的浪费,丢失有用信息,
- 二是在融合过程中只能使用固定权重,无法自适应地调整前序帧权重,
- 三是可用的时序区间也比较短,因为时序过长,可融合区域会更小,难以起到加强作用.**BEVFormer的实验中,融合3帧,也就是2s的时序区间效果达到了峰值.**


### UniFusion(浙江大学,大疆,上海AI lab)

[论文链接](https://arxiv.org/abs/2207.08536)
[代码链接](https://github.com/cfzd/UniFusion)


 ![网络结构图](/pic/time10.png)

Uniformer解释了基于warp的融合方式为什么会带来信息丢失.如下图所示,图(b)的灰色部分是连续两帧实际可融合区域,图(a)的灰色部分是生成一定范围内的矩形的bev feature后实际融合的区域,可见融合范围大大缩小,所以很多有用的信息被浪费了.


 ![不同视角](/pic/time8.png)


为了更好地融合时序信息,可以不在bev空间通过warp的方式进行融合,而是把这一过程提前到**图像空间**,通过缓存前序帧的图像特征,并把前序帧的lidar2img参数,也就是相机外参转换到当前帧,那就**等同于当前帧又多了很多个相机视角**,同时可以看到更大范围的信息,图上图(c)所示.在这种架构下,多帧时间的融合和多视角空间的融合被统一起来了,所以模型命名为Uniformer.下图更加直观地展示了两种方法的区别:

  ![](/pic/time9.png)

Uniformer架构可以解决上述warp方法的全部缺陷.
- 第一点,它不造成信息浪费,可以融合当前帧和前序帧相机视角所能覆盖的所有区域,
- 第二点,它可以自适应地学习每个视角的权重,不区分当前和前序帧,
- 第三,只要缓存空间允许,它可以融合很长的时序区间.当然这种方法的**劣势是需要缓存多视角特征,无法使用较大的分辨率**,一般需要高倍下采样,最后再进行上采样.Uniformer为这种方法取名为"virtual views"即虚拟视角方法.

在具体实现上,Uniformer的前序帧选取前6帧,时序对齐的方式如上文所述,通过外参转换的方式将前序帧变为当前帧的虚拟视角,然后做基于transformer的融合,包括self attention和cross attention,只是cross attention同时融合了时间和空间信息.最后还设计了self-regression自回归模块来融合多层transformer结果,最后得到bev feature,并指出这种方法也能达到类似于BEVFormer将前序帧和当前帧bev feature进行concate再融合的提升效果.bev feature分辨率采用50*50再用4倍上采样.实验效果对比如下图所示: