# BEV下的多模态特征融合方法汇总


[Lidar and camera-based 3D objection detection 激光雷达和图像结合的3D目标检测方法](https://zhuanlan.zhihu.com/p/434071599?utm_id=0)