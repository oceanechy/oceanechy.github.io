# Efficient Spatial-Temporal Information Fusion for LiDAR-Based 3D Moving Object Segmentation (motionseg3D)

单帧点云数据的语义分割目前有几种常见的方案,如：
- 基于原始点云数据结构；
- 将点云栅格化，以体素 Voxel 进行输入；
- 将点云经球形投影到距离图像（Range Image）；
- 将点云投影到鸟瞰图（Bird Eye’s View）。

其中直接对 3D 点云进行计算的时间复杂度高、内存占用较高、栅格化会丢失一部分原始数据信息，鸟瞰图则会丢失高度信息。基于Range Iamge的方法是一个相对轻量级的中间表示，然而，在将其back-projection回3D点云时，存在边界模糊问题


该方法提出了一种新颖有效的基于激光雷达的在线运动目标分割网络，网络使用双分支结构，以更好的融合空间信息和时间信息，并引入了一种“由粗到细”的策略来减少物体边界上的边界模糊问题，在保持实时性的同时，性能一举超越之前的网络

双分支结构：与LMNet不同，LMNet直接将距离图像和残差图像连接在一起作为原始SalsaNext的输入，而motionseg3D论文提出了双分支的网络结果，一个分支处理时间维度的信息，主要通过多帧运动残差图像（Residual Image）来建模和编码帧间的运动信息，第二个分支更关注空间信息，通过 Range Image 来进行几何及语义信息的提取；同时我们引入了一个 Motion Attention 注意力机制模块用于时空信息的有效融合。

具体的，为了解决传统 2D 卷积无法有效的捕获 Range Image 中隐含的 3D 空间信息问题，引入了 RangeDet 中的 Meta-Kernel 模块，以从相对笛卡尔坐标学习动态权重;

其次，受视频目标分割的启发，添加了一个空间和通道注意力模块来从残差图像中提取运动信息，利用运动信息，加强外观特征中某些重点区域的响应，最终生成一个时空融合特征

最后，为了解决物体不边界上的伪影问题，提出PointHead模块，利用了像素级和点级的误差去训练，使得训练过程更加有效，参数优化更为容易。


# 基于视觉图像的三维检测

ImVoxelNet: Image to Voxels Projection for Monocular and Multi-View General-Purpose 3D Object Detection：端到端的基于单帧或者多帧（每个场景帧数可以不一样）RGB图像的3D目标检测，能够兼容室内和室外（主要针对自动驾驶）的场景，为了融合不同输入的信息，作者构建了一个 3D 空间的体素表征，然后从该 3D 特征图做最终的预测，类似于点云检测的方式。室内与室外分别进行设计，室内的3D目标检测借鉴2D FCOS网络，检测头包含三个3D卷积层分别用于分类、定位、中心点的预测，对所有的尺度都共享权重将室外 3D 检测看作为 BEV 平面的 2D 目标检测

SMOKE: Single-Stage Monocular 3D Object Detection via Keypoint Estimation：基于CenterNet的框架，主干网络使用DLA34，另外加上两个独立的分支，热力图分支：将3D框的中心点(x,y,z)通过相机内参内参矩阵K投影到图像上，作为模型需要预测的2D中心点(xc,yc)；深度回归分支：使用预定义的均值和标准差对深度进行标准化，如果知道模型预测某物体中心的位置,局部偏移量以及归一化后的深度,则可反推物体的3D中心坐标；其他分支：长宽高进行归一化，转向角度（物体朝向与坐标轴夹角）

FCOS3D: Fully Convolutional One-Stage Monocular 3D Object Detection：基于2D检测中的FCOS模型，主干网络和FPN不变，两个分支分别预测类别(分类)和3D参数(回归)，其中对3D框的7个预测值进行编码，使其更适应2D检测模型，转向角编码为正弦值和方向分别预测，同时增加额外预测分支预测所有的3D参数

Probabilistic and Geometric Depth（PGD）: Detecting Objects in Perspective:也可以被视为FCOS3D++，是一种简单而有效的单目3D探测器。它通过涉及局部几何约束和改进实例深度估计来增强 FCOS3D 基线

Objects are Different（MonoFlex）: Flexible Monocular 3D Object Detection：一种用于单目 3D 对象检测的灵活框架，该框架显式解耦截断对象并自适应组合多种方法进行对象深度估计。框架是从CenterNet扩展而来的, 在共享主干上部署了多个预测分支，以回归目标的属性，包括2D边界框、维度、方向、关键点和深度。最终的深度估计是回归深度和根据估计的关键点和维度计算的深度的不确定性引导的组合。

总结，目前看到的基于图像的三维目标检测基本上都是在2D检测上迁移过来，其中使用最多的基于anchor-free方式的网络，如CenterNet,FCOS，在此类网络上进行魔改