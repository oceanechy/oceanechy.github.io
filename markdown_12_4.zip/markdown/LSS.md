从相机视角向BEV视角下的转变目前感觉比较主流的方法可以大体分为两种：1）显式估计图像的深度信息，完成BEV视角的构建，在某些文章中也被称为自下而上的构建方式；2）利用transformer中的query查询机制，利用BEV Query构建BEV特征，这一过程也被称为自上而下的构建方式；


# LSS :Lift, Splat, Shoot: Encoding Images from Arbitrary Camera Rigs by Implicitly Unprojecting to 3D

通过显式估计图像的深度信息，对采集到的环视图像进行特征提取，并根据估计出来的**离散深度信息**，实现图像特征向BEV特征的转换，进而完成自动驾驶中的语义分割任务。
 
参考代码：
LSS算法包括的五个步骤。
 - 1）生成视锥 **(图像坐标系DxfHxfWx3)**，并根据相机内外参将视锥中的点投影到ego坐标系 **(图像坐标系 -> 归一化相机坐标系 -> 相机坐标系 -> 车身坐标系(B, N, D, H, W, 3))**；
 - 2）对环视图像完成特征的提取**使用Efficientnet-B0主干网络，输入环视图像(bs, N, 3, H, W) -> (bs x N, 3, H, W),最后得融合特征(bs x N, 512, H / 16, W / 16)**，并构建图像特征点云**使用的1x1卷积层，(bs x N, 512, H / 16, W / 16)->(bs xN, 105, H / 16, W / 16),第二维的105个通道分成两部分；第一部分：前41个维度代表不同深度上41个离散深度;第二部分：后64个维度代表特征图上的不同位置对应的语义特征,利用得到的深度方向的概率密度和语义特征通过外积运算构建图像特征点云,(bs xN, 64, 41, H / 16, W / 16)**；
 - 3）将ego坐标系的点栅格化为体素坐标并展平 **(BxNxDxHxW, 3)**,同时为每个点加上batch序号 **(BxNxDxHxW, 4)**并去掉栅格范范围之外的点，另外为每个点计算一个rank值，根据rank排序使得同一个栅格的特征向量相邻，利用cumsum_trick函数进行Voxel Pooling，最后将图像特征点云按照栅格坐标放到final中 **(B x C x 1 x 200 x 200)，消除掉z维(B x 64 x 200 x 200) 构建BEV特征**；
 - 4）对生成的BEV特征利用BEV Encoder做进一步的特征融合 **(ResNet-18,(B x 64 x 200 x 200)->(B, 1, 200, 200)** 第二个维度的1就代表BEV每个网格下的二分类结果)；
 - 5）利用特征融合后的BEV特征完成语义分割任务 **(基于像素的交叉熵损失)**；

Lft-Splat创新点
 - depth-net后增加对d方向的conv
 - 对cumsum:结果求mean,使得splat后的BEV特征图保持同一尺度
 - 归一化采样，BEV特征图乘以f(X)=X*abs(x)/50*abs(y)/50(灵感来自CT的傅里叶变换)
 - 2D全景分割辅助训练（目标检测与分割任务同等有效）
 - 增大decoder感受野，使其有纠错能力
 - 时序特征：在bev decoder部分抽取一个特征图，根据EGMO对齐到下一帧，concat(BEVDet4D)
 - cumsum部署问题


# BEVDet: High-Performance Multi-Camera 3D Object Detection in Bird-Eye-View

基于LSS的自底向上建立BEV的方法

具体流程：
 - 先对多视角图像进行特征提取（Image-view Encoder）,
 - 再通过基于LSS的视角转换（View Transformer）将多视角特征投影到bev空间下，
 - 再用和第一步类似的backbone对bev特征进行编码
 - 最后加检测头进行目标检测