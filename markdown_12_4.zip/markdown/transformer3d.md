## DETR3D: 3D Object Detection from Multi-view Images via 3D-to-2D Queries

基于多视角的3D目标检测，基于nuScenes数据集，基于DETR，DETR的大致过程是提取图像特征→编码辅助输入→结合queries获得values→得到queries的检测结果，DETR3D 将生成的 3D 参考点重复投影到图像平面，并对 2D 特征进行采样以与解码器中的对象查询进行交互

DETR3D模型的设计主要包括三部分：Encoder，Decoder和Loss。

Encoder:在nuScenes数据集中，每个样本含有6张环视相机图片。我们用ResNet去对每张图片进行encode来提取特征，然后再接一个FPN输出4层multi-scale features。

Decoder:Detection head共含有6层transformer decoder layer。类似于DETR，我们预先设置300/600/900个object query，每个query是256维的embedding。所有的object query**由一个全连接网络**预测出在BEV空间中的**3D reference point坐标(x, y, z)**，坐标经过sigmoid函数归一化后表示在空间中的相对位置。在每层layer之中，所有的object query之间做self-attention来相互交互获取全局信息并避免多个query收敛到同个物体。

object query再和图像特征之间做cross-attention：将每个query对应的3D reference point通过相机的内参外参投影到图片坐标，利用线性插值来采样对应的multi-scale image features，如果投影坐标落在图片范围之外就补零，之后再用采用的图像特征去更新object queries。

经过attention更新后的object query通过两个MLP网络来分别预测对应物体的class和bounding box的参数。为了让网络更好的学习，我们每次都预测bounding box的中心坐标相对于**reference points**的offset来更新reference points的坐标。

每层更新的object queries和reference points作为下一层decoder layer的输入，再次进行计算更新，总共迭代6次。

Loss:损失函数的设计也主要受DETR的启发，我们在所有object queries预测出来的检测框和所有的ground-truth bounding box之间利用匈牙利算法进行二分图匹配，找到使得loss最小的最优匹配，并计算classification focal loss和L1 regression loss。

## PETR: Position Embedding Transformation for Multi-View 3D Object Detection

在DETR3D上进行改进，PETR通过3D Position Embedding将多视角相机的2D特征转化为3D感知特征，使得object query可以直接在3D语义环境下更新，省去了参考点反投影以及特征采样两个步骤

总结一下Query的生成：DETR使用一组可学习的参数作为初始的object query，DETR3D基于初始的object query预测一组参考点，PETR为了降低3D场景的收敛难度，首先在3D世界空间中以均匀分布的方式初始化一组可学习的3D锚点，然后锚点经过一个小型MLP生成初始的object query

## PETRv2:A Unified Framework for 3D Perception from Multi-Camera Images

PETR中的3D PE扩展到时序版本，通过对生成的3D coordinates进行变换，实现了时序对齐，引入了一个特征引导的位置编码器，使得3D PE的生成和输入数据相关，隐式地从特征中获取到深度等信息，同时引入了一些分割查询向量，每个分割查询变量用于BEV分割

## StreamPETR:Exploring Object-Centric Temporal Modeling for Efficient Multi-View 3D Object Detection


## Cross Modal Transformer(CMT): Towards Fast and Robust 3D Object Detection

一种鲁棒的多模态3D目标检测器，以相机和点云tokens作为输入，直接输出准确3D检测框，并通过将3D点编码进多模态特征来多模态tokens的空间对齐

基于DETR,连接图像和点云tokens，并与object queries进行交互,提出坐标编码模块（CEM），为多模态tokens提供位置先验，同时提出position-guided queries,为object queries提供位置先验，