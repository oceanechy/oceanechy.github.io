# BEVDet在服务器上环境搭建以及运行记录

## 流程

- 创建conda虚拟环境：
  ```python
  conda create --name BEVDet python=3.8 -y
  ```
- 在虚拟环境里安装torch：
  ```python
  conda install pytorch==1.10.0 torchvision==0.11.0 cudatoolkit=11.3 -c https://mirrors.tuna.tsinghua.edu.cn/anaconda/cloud/pytorch/linux-64/
  ```
- 安装mmcv-full:
  ```python
  pip install mmcv-full==1.5.3 -f https://download.openmmlab.com/mmcv/dist/cu113/torch1.10.0/index.html  -i https://pypi.tuna.tsinghua.edu.cn/simple
  ```
- 安装mmdet：
  ```python
  pip install mmdet==2.25.1 mmsegmentation==0.25.0  -i https://pypi.tuna.tsinghua.edu.cn/simple
  ```

- 安装其他：
  ```python
  pip install pycuda \
      lyft_dataset_sdk \
      networkx==2.2 \
      numba==0.53.0 \
      numpy==1.23.5 \
      nuscenes-devkit \
      yapf==0.40.1\
      setuptools==59.5.0\
      plyfile \
      scikit-image \
      tensorboard \
      trimesh==2.35.39 -i https://pypi.tuna.tsinghua.edu.cn/simple
  ```

- 最后安装整个项目：
  ```python
  pip install -e .
  ```

- 多机训练：
  ```python
  CUDA_VISIBLE_DEVICES=0,1,2,3 PORT=29500 ./tools/dist_train.sh ${CONFIG_FILE} 4
  ```

```python
CUDA_VISIBLE_DEVICES=7 PORT=29510 ./tools/dist_train.sh configs/bevdet/bevdet-r50.py 1 
```

<br/>

### 报错 TypeError: FormatCode() got an unexpected keyword argument ‘verify’

原因：yapf版本过高
由0.40.2 切换成 0.40.1问题解决

pip install yapf==0.40.1

### 警告'Creating a tensor from a list of numpy.ndarrays is extremely slow'

总结
(1) 对于不含numpy.ndarrays的list而言，list->tensor明显快于list->numpy.ndarrays->tensor (1.7s<2.5s);

(2) 对于含有numpy.ndarrays的list而言，list->numpy.ndarrays->tensor明显快于list->tensor (18.8s<41.2s).

[参考链接](https://zhuanlan.zhihu.com/p/429901066)

### 报错： AttributeError: module ‘distutils’ has no attribute ‘version’.

解决： setuptools版本问题”，版本过高导致的问题；setuptools版本

第一步： pip uninstall setuptools【使用pip，不能使用 conda uninstall setuptools ; 【不能使用conda的命令，原因是，conda在卸载的时候，会自动分析与其相关的库，然后全部删除，如果y的话，整个环境都需要重新配置。

第二步： pip或者conda install setuptools==59.5.0【现在最新的版本已经到了68了，之前的老版本只是部分保留，找不到的版本不行


### Ubuntu安装ninja

Ninja是一个比Make更快速的小型构建系统。其github地址为：https://ninja-build.org/

[不同安装方式](https://blog.csdn.net/SHH_1064994894/article/details/129268006)

[Ninja安装和基本使用](https://blog.csdn.net/qq_36287943/article/details/105343192?spm=1001.2101.3001.6650.2&utm_medium=distribute.pc_relevant.none-task-blog-2%7Edefault%7ECTRLIST%7ERate-2-105343192-blog-129268006.235%5Ev38%5Epc_relevant_anti_vip_base&depth_1-utm_source=distribute.pc_relevant.none-task-blog-2%7Edefault%7ECTRLIST%7ERate-2-105343192-blog-129268006.235%5Ev38%5Epc_relevant_anti_vip_base&utm_relevant_index=5)

pip3 install ninja

## [BEVDet系列源码解读](https://zhuanlan.zhihu.com/p/557613388)

![截图](fb9cef23d1dd44e2f67fad259113ad1b.png)

**BEVDet方法:关键是其中的第二步View Transformer将图像特征转化为BEV特征的过程并使用cuda实现了高效的voxel_pooling_v2在后处理中也提出了scale-NMS可以针对不同尺度的物体进行缩放然后进行过滤。**

[系列解读链接](https://www.zhihu.com/column/c_1502288547017617408)

## nuScenes使用介绍以及BEVDet进行训练

[csdn](https://blog.csdn.net/weixin_44596312/article/details/122300131)

[mmdet3d解说](https://mmdetection3d.readthedocs.io/zh-cn/latest/advanced_guides/datasets/nuscenes.html)

### 在mini-v1.0训练测试

mini-v1.0里面有三类物体（C.V.、Trailer、Barrier）不包含，其他物体数量也比较少，所以最后的性能上会比较低。

![截图](6a46792dc50f7f77a616b9c0fc84113c.png)

![截图](4e597a394f9c1492958cc248049f4fe3.png)

![1699529096094.png](e77bbdc1106b3b95edfee3277d314dd3.png)

### 相关检测参数指标

[参考链接](https://blog.csdn.net/weixin_45097875/article/details/125846945)

#### mAP:

在评测时依旧使用目标检测中常用的的AP，不过AP的阈值匹配不使用IoU来计算，而使用在地平面上的2D中心距离d来计算。这样解耦了物体的尺寸和方向对AP计算的影响。d设置为{0.5,1,2,4}米。在计算AP时，去除了低于0.1的recall和precision并用0来代替这些区域。不同类以及不同难度D用来计算mAP：

#### mATE：

Average Translation Error,平均平移误差(ATE) 是二维欧几里德中心距离(单位为米).

#### mASE：

Average Scale Error, 平均尺度误差(ASE) 是1 - IoU, 其中IoU 是角度对齐后的三维交并比

#### mAOE：

Average Orientation Error.平均角度误差(AOE) 是预测值和真实值之间最小的偏航角差。(所有的类别角度偏差都在360∘度内, 除了障碍物这个类别的角度偏差在180∘ 内)

#### mAVE：

 Average Velocity Error.平均速度误差(AVE) 是二维速度差的L2 范数(m/s)。

#### mAAE：

Average Attribute Error,平均属性错误(AAE) 被定义为1−acc, 其中acc 为类别分类准确度。

![截图](bd1a7e7e4cdf242c91e2ecd6e1f7eabb.png)

![截图](6a46792dc50f7f77a616b9c0fc84113c.png)

<br/>

可以看出每个参数的性能指标

## BEVDet中nuscenes数据集处理

处理前的结构

```python
mmdetection3d
├── mmdet3d
├── tools
├── configs
├── data
│   ├── nuscenes
│   │   ├── maps
│   │   ├── samples
│   │   ├── sweeps
│   │   ├── v1.0-test
|   |   ├── v1.0-trainval
```

处理使用命令

```python
python tools/create_data.py nuscenes --root-path ./data/nuscenes --out-dir ./data/nuscenes --extra-tag nuscenes
```

处理后的结构

```python
mmdetection3d
├── mmdet3d
├── tools
├── configs
├── data
│   ├── nuscenes
│   │   ├── maps
│   │   ├── samples
│   │   ├── sweeps
│   │   ├── v1.0-test
|   |   ├── v1.0-trainval
│   │   ├── nuscenes_database
│   │   ├── nuscenes_infos_train.pkl
│   │   ├── nuscenes_infos_val.pkl
│   │   ├── nuscenes_infos_test.pkl
│   │   ├── nuscenes_dbinfos_train.pkl
│   │   ├── nuscenes_infos_train_mono3d.coco.json
│   │   ├── nuscenes_infos_val_mono3d.coco.json
│   │   ├── nuscenes_infos_test_mono3d.coco.json
```

![截图](3965332f9620a419a12dff851c3b6de2.png)

![截图](23ecfbfcf5e0597b8c2a808e2a138b0b.png)
