# MonoScene在服务器上环境搭建以及运行记录

## conda环境

```python
pytorch-lightning_libgcc_mutex             0.1                        main    defaults
_openmp_mutex             5.1                       1_gnu    defaults
absl-py                   2.0.0                    pypi_0    pypi
aiohttp                   3.8.6                    pypi_0    pypi
aiosignal                 1.3.1                    pypi_0    pypi
antlr4-python3-runtime    4.8                      pypi_0    pypi
async-timeout             4.0.3                    pypi_0    pypi
asynctest                 0.13.0                   pypi_0    pypi
attrs                     23.1.0                   pypi_0    pypi
blas                      1.0                         mkl    defaults
ca-certificates           2023.08.22           h06a4308_0    defaults
cachetools                5.3.2                    pypi_0    pypi
certifi                   2022.12.7        py37h06a4308_0    defaults
charset-normalizer        3.3.1                    pypi_0    pypi
cudatoolkit               10.2.89              hfd86e86_1    defaults
cycler                    0.11.0                   pypi_0    pypi
fonttools                 4.38.0                   pypi_0    pypi
freetype                  2.12.1               h4a9f257_0    defaults
frozenlist                1.3.3                    pypi_0    pypi
fsspec                    2023.1.0                 pypi_0    pypi
future                    0.18.3                   pypi_0    pypi
giflib                    5.2.1                h5eee18b_3    defaults
google-auth               2.23.3                   pypi_0    pypi
google-auth-oauthlib      0.4.6                    pypi_0    pypi
grpcio                    1.59.0                   pypi_0    pypi
hydra-core                1.0.5                    pypi_0    pypi
idna                      3.4                      pypi_0    pypi
imageio                   2.31.2                   pypi_0    pypi
importlib-metadata        6.7.0                    pypi_0    pypi
importlib-resources       5.12.0                   pypi_0    pypi
intel-openmp              2021.4.0          h06a4308_3561    defaults
joblib                    1.3.2                    pypi_0    pypi
jpeg                      9b                   h024ee3a_2    defaults
kiwisolver                1.4.5                    pypi_0    pypi
lcms2                     2.12                 h3be6417_0    defaults
ld_impl_linux-64          2.38                 h1181459_1    defaults
libffi                    3.4.4                h6a678d5_0    defaults
libgcc-ng                 11.2.0               h1234567_1    defaults
libgomp                   11.2.0               h1234567_1    defaults
libpng                    1.6.39               h5eee18b_0    defaults
libstdcxx-ng              11.2.0               h1234567_1    defaults
libtiff                   4.1.0                h2733197_1    defaults
libuv                     1.44.2               h5eee18b_0    defaults
libwebp                   1.2.0                h89dd481_0    defaults
llvmlite                  0.36.0                   pypi_0    pypi
lz4-c                     1.9.4                h6a678d5_0    defaults
markdown                  3.4.4                    pypi_0    pypi
markupsafe                2.1.3                    pypi_0    pypi
matplotlib                3.5.3                    pypi_0    pypi
mkl                       2021.4.0           h06a4308_640    defaults
mkl-service               2.4.0            py37h7f8727e_0    defaults
mkl_fft                   1.3.1            py37hd3c417c_0    defaults
mkl_random                1.2.2            py37h51133e4_0    defaults
monoscene                 0.0.0                     dev_0    <develop>
multidict                 6.0.4                    pypi_0    pypi
ncurses                   6.4                  h6a678d5_0    defaults
networkx                  2.6.3                    pypi_0    pypi
ninja                     1.10.2               h06a4308_5    defaults
ninja-base                1.10.2               hd09550d_5    defaults
numba                     0.53.0                   pypi_0    pypi
numpy                     1.20.3                   pypi_0    pypi
nvidia-cublas-cu11        11.10.3.66               pypi_0    pypi
nvidia-cuda-nvrtc-cu11    11.7.99                  pypi_0    pypi
nvidia-cuda-runtime-cu11  11.7.99                  pypi_0    pypi
nvidia-cudnn-cu11         8.5.0.96                 pypi_0    pypi
oauthlib                  3.2.2                    pypi_0    pypi
omegaconf                 2.0.6                    pypi_0    pypi
opencv-python             4.5.1.48                 pypi_0    pypi
openssl                   1.1.1w               h7f8727e_0    defaults
packaging                 23.2                     pypi_0    pypi
pillow                    9.3.0            py37hace64e9_1    defaults
pip                       22.3.1           py37h06a4308_0    defaults
protobuf                  3.19.6                   pypi_0    pypi
pyasn1                    0.5.0                    pypi_0    pypi
pyasn1-modules            0.3.0                    pypi_0    pypi
pydeprecate               0.3.1                    pypi_0    pypi
pyparsing                 3.1.1                    pypi_0    pypi
python                    3.7.16               h7a1cb2a_0    defaults
python-dateutil           2.8.2                    pypi_0    pypi
pytorch-lightning         1.4.9                    pypi_0    pypi
pywavelets                1.3.0                    pypi_0    pypi
pyyaml                    5.3.1                    pypi_0    pypi
readline                  8.2                  h5eee18b_0    defaults
requests                  2.31.0                   pypi_0    pypi
requests-oauthlib         1.3.1                    pypi_0    pypi
rsa                       4.9                      pypi_0    pypi
scikit-image              0.18.1                   pypi_0    pypi
scikit-learn              0.24.0                   pypi_0    pypi
scipy                     1.7.3                    pypi_0    pypi
setuptools                65.6.3           py37h06a4308_0    defaults
six                       1.16.0             pyhd3eb1b0_1    defaults
sqlite                    3.41.2               h5eee18b_0    defaults
tbb                       2020.2               hff7bd54_0    defaults
tensorboard               2.11.2                   pypi_0    pypi
tensorboard-data-server   0.6.1                    pypi_0    pypi
tensorboard-plugin-wit    1.8.1                    pypi_0    pypi
threadpoolctl             3.1.0                    pypi_0    pypi
tifffile                  2021.11.2                pypi_0    pypi
tk                        8.6.12               h1ccaba5_0    defaults
torch                     1.13.1                   pypi_0    pypi
torchaudio                0.7.2                      py37    pytorch
torchmetrics              0.6.0                    pypi_0    pypi
torchvision               0.8.2                py37_cu102    pytorch
tqdm                      4.49.0                   pypi_0    pypi
typing_extensions         4.3.0            py37h06a4308_0    defaults
urllib3                   2.0.7                    pypi_0    pypi
werkzeug                  2.2.3                    pypi_0    pypi
wheel                     0.38.4           py37h06a4308_0    defaults
xz                        5.4.2                h5eee18b_0    defaults
yarl                      1.9.2                    pypi_0    pypi
zipp                      3.15.0                   pypi_0    pypi
zlib                      1.2.13               h5eee18b_0    defaults
zstd                      1.4.9                haebb681_0    defaults
```

**需要注意的是这里使用了pytorch-lightning，版本对应安装**

[官方文档连接](https://lightning.ai/docs/pytorch/latest/starter/introduction.html)

![截图](a93ac42b74810deb39e5ea6dc4f5a66e.png)

## 数据集使用SemanticKITTI以及NYUv2

[Semantic Scene Completion dataset v1.1下载地址](http://www.semantic-kitti.org/dataset.html#download)

[ KITTI Odometry Benchmark calibration data (Download odometry data set (calibration files, 1 MB)) and the RGB images (Download odometry data set (color, 65 GB))](https://www.cvlibs.net/datasets/kitti/eval_odometry.php)

```python
$ export KITTI_PREPROCESS=/home3/dataset/kitti/preprocess
$ export KITTI_ROOT=/home3/dataset/kitti/semantic_kitti
$ export KITTI_LOG=/home3/chenhaiyang/MonoScene/monoscene/data/semantic_kitti/logdir
```

- KITTI_PREPROCESS保存的是未处理的数据

- KITTI_ROOT保存的是处理后的数据
- KITTI_LOG保存的是日志文件

### kitti数据集标注解释

[参考链接1](https://zhuanlan.zhihu.com/p/452672948)

[参考链接2](https://blog.csdn.net/yangziluomu/article/details/78339575)

```txt
1惯性导航系统（GPS / IMU）：OXTS RT 3003
1台激光雷达：Velodyne HDL-64E
2台灰度相机，1.4百万像素：Point Grey Flea 2（FL2-14S3M-C）
2个彩色摄像头，1.4百万像素：Point Grey Flea 2（FL2-14S3C-C）
4个变焦镜头，4-8毫米：Edmund Optics NT59-917
```

![截图](9dd8f665b331552caace5d45f362b48e.png)

#### calib.txt 标定文件解读

在calib文件中，有sequence 00-21序列，包括calib.txt 和 times.txt文件。
在sequence calib.txt 中，

```python
P0: 7.188560000000e+02 0.000000000000e+00 6.071928000000e+02 0.000000000000e+00 0.000000000000e+00 7.188560000000e+02 1.852157000000e+02 0.000000000000e+00 0.000000000000e+00 0.000000000000e+00 1.000000000000e+00 0.000000000000e+00
P1: 7.188560000000e+02 0.000000000000e+00 6.071928000000e+02 -3.861448000000e+02 0.000000000000e+00 7.188560000000e+02 1.852157000000e+02 0.000000000000e+00 0.000000000000e+00 0.000000000000e+00 1.000000000000e+00 0.000000000000e+00
P2: 7.188560000000e+02 0.000000000000e+00 6.071928000000e+02 4.538225000000e+01 0.000000000000e+00 7.188560000000e+02 1.852157000000e+02 -1.130887000000e-01 0.000000000000e+00 0.000000000000e+00 1.000000000000e+00 3.779761000000e-03
P3: 7.188560000000e+02 0.000000000000e+00 6.071928000000e+02 -3.372877000000e+02 0.000000000000e+00 7.188560000000e+02 1.852157000000e+02 2.369057000000e+00 0.000000000000e+00 0.000000000000e+00 1.000000000000e+00 4.915215000000e-03
Tr: 4.276802385584e-04 -9.999672484946e-01 -8.084491683471e-03 -1.198459927713e-02 -7.210626507497e-03 8.081198471645e-03 -9.999413164504e-01 -5.403984729748e-02 9.999738645903e-01 4.859485810390e-04 -7.206933692422e-03 -2.921968648686e-01
```

0,1,2,3 代表相机的编号，0表示左边灰度相机，1右边灰度相机，2左边彩色相机，3右边彩色相机。Tr表示将velodyne坐标系转换到左边相机系统坐标。

根据calib.txt相机投影矩阵可以得到相机内参。

![截图](9b517ca2a52c3bcf686f3d2b598f234e.png)

![截图](c7a26d5ae792b4f518aa79e835c820fa.png)

## 网络训练

```python
python monoscene/scripts/train_monoscene.py \
    dataset=kitti \
    enable_log=true \
    kitti_root=$KITTI_ROOT \
    kitti_preprocess_root=$KITTI_PREPROCESS\
    kitti_logdir=$KITTI_LOG \
    n_gpus=3 batch_size=3
```

服务器上的显存不够，训练不了

为了能够训练，可能采取的方法：

- 更改2D解码器的特征尺寸
- 缩小输入图像：还需要调整投影矩阵
- 通过更改basemodel_name 和 num_features来使用较小的 2D 主干。
- 减少3D网络的特征维度
- 尝试先禁用或减小上下文的大小

[参考](https://github.com/astra-vision/MonoScene/issues/25)

### 记录一下代码的构造

- 2d unet结构的创建 编码器使用rwightman/gen-efficientnet-pytorch下的tf_efficientnet_b7_ns作为backbone,解码器自己创建的上采样层

- FLoSP结构将2d特征提升至三维的
- 3D UNets：2层 encoder-decoder 结构，用于提取 3d 特征
- completion head：3D ASPP 结构和 softmax 层，用于处理 3D UNet 输出得到3d场景 completion 结果

#### 介绍一下efficientnet

[参考链接](https://blog.csdn.net/qq_37541097/article/details/114434046)

![截图](a221d02adcef4934cb9c8a3f909d0b52.png)

在之前的一些论文中，有的会通过增加网络的width即增加卷积核的个数（增加特征矩阵的channels）来提升网络的性能如图(b)所示，有的会通过增加网络的深度即使用更多的层结构来提升网络的性能如图(c)所示，有的会通过增加输入网络的分辨率来提升网络的性能如图(d)所示。而在本篇论文中会同时增加网络的width、网络的深度以及输入网络的分辨率来提升网络的性能如图(e)所示：


![截图](a060b74b18a9239af2a8fb22663a2feb.png)

![截图](2f6cb84d74f69886fa0d803d7702118a.png)

<br/>

**未完待续~**